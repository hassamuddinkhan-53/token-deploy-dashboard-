/**
 * QUICK REFERENCE: Live On-Chain Data Functions
 * Copy these snippets directly into your React components
 */

// ============================================================================
// 1. FETCH LIVE TOKEN SUPPLY
// ============================================================================
import { getTotalSupply, formatBalance } from './contract/token';
import { TOKEN_ADDRESS } from '../config.js';

async function loadSupply() {
  const supply = await getTotalSupply(TOKEN_ADDRESS);
  const formatted = formatBalance(supply, 18);
  console.log('Supply:', formatted);
}

// ============================================================================
// 2. FETCH LIVE TOKEN PRICE
// ============================================================================
import { getTokenPrice } from './contract/token';
import { TOKEN_ADDRESS, DAI_ADDRESS } from '../config.js';

async function loadPrice() {
  const price = await getTokenPrice(TOKEN_ADDRESS, DAI_ADDRESS, 18);
  console.log('Price:', price, 'DAI');
  // Returns: 0.0523 = $0.0523 per token
}

// ============================================================================
// 3. FETCH HOLDERS DISTRIBUTION
// ============================================================================
import { getHoldersDistribution } from './contract/token';

async function loadHolders() {
  const distribution = await getHoldersDistribution(TOKEN_ADDRESS);
  console.log('Holders:', distribution);
  // Returns: [
  //   { name: '0x123...abc', value: 25.5 },
  //   { name: '0x456...def', value: 18.3 },
  //   ...
  // ]
  // Use directly in Recharts PieChart!
}

// ============================================================================
// 4. FETCH PAIR LIQUIDITY
// ============================================================================
import { getPairLiquidity, formatBalance } from './contract/token';
import { TOKEN_ADDRESS, SEPOLIA_WETH } from '../config.js';

async function loadLiquidity() {
  const pair = await getPairLiquidity(TOKEN_ADDRESS, SEPOLIA_WETH);
  if (pair) {
    const reserve0 = formatBalance(pair.reserve0, 18);
    const reserve1 = formatBalance(pair.reserve1, 18);
    console.log('Token Reserve:', reserve0);
    console.log('WETH Reserve:', reserve1);
  }
}

// ============================================================================
// 5. PERFORM SWAP
// ============================================================================
import { swapExactTokens, approve } from './contract/token';
import { DAI_ADDRESS, USDC_ADDRESS } from '../config.js';
import { parseUnits } from 'ethers';

async function performSwap(walletAddress) {
  try {
    const amountIn = parseUnits('100', 18); // 100 DAI
    const path = [DAI_ADDRESS, USDC_ADDRESS];

    // Step 1: Approve DAI to router
    await approve(DAI_ADDRESS, '0x3F947239c4dBFCC5B6EbcF8CF52b204D06AC2Cc1', '100', 18);
    console.log('Approved!');

    // Step 2: Perform swap
    const tx = await swapExactTokens(amountIn, path, walletAddress, 1); // 1% slippage
    console.log('Swap executed:', tx.hash);
  } catch (error) {
    console.error('Swap failed:', error.message);
  }
}

// ============================================================================
// REACT COMPONENT EXAMPLES
// ============================================================================

// EXAMPLE 1: Display live token supply
import React, { useEffect, useState } from 'react';
import { getTotalSupply, formatBalance } from '../contract/token';
import { TOKEN_ADDRESS } from '../../config.js';
import { useStore } from '../context/store';

export function SupplyCard() {
  const { isConnected } = useStore();
  const [supply, setSupply] = useState('0');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isConnected) return;

    const fetch = async () => {
      setLoading(true);
      try {
        const s = await getTotalSupply(TOKEN_ADDRESS);
        const formatted = formatBalance(s, 18);
        setSupply(formatted);
      } catch (error) {
        console.error('Failed to fetch supply:', error);
      } finally {
        setLoading(false);
      }
    };

    fetch();
    const interval = setInterval(fetch, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, [isConnected]);

  return (
    <div>
      {loading && <p>Loading...</p>}
      {!loading && <p>Supply: {supply} tokens</p>}
    </div>
  );
}

// EXAMPLE 2: Display live price
export function PriceCard() {
  const { isConnected } = useStore();
  const [price, setPrice] = useState('0');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isConnected) return;

    const fetch = async () => {
      setLoading(true);
      try {
        const p = await getTokenPrice(TOKEN_ADDRESS, DAI_ADDRESS, 18);
        setPrice(p.toFixed(4));
      } catch (error) {
        console.error('Failed to fetch price:', error);
      } finally {
        setLoading(false);
      }
    };

    fetch();
    const interval = setInterval(fetch, 30000);
    return () => clearInterval(interval);
  }, [isConnected]);

  return (
    <div>
      {loading && <p>Loading...</p>}
      {!loading && <p>Price: ${price}</p>}
    </div>
  );
}

// EXAMPLE 3: Holders pie chart
export function HoldersChart() {
  const { isConnected } = useStore();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isConnected) return;

    const fetch = async () => {
      setLoading(true);
      try {
        const dist = await getHoldersDistribution(TOKEN_ADDRESS);
        setData(dist);
      } catch (error) {
        console.error('Failed to fetch holders:', error);
      } finally {
        setLoading(false);
      }
    };

    fetch();
    const interval = setInterval(fetch, 30000);
    return () => clearInterval(interval);
  }, [isConnected]);

  return (
    <div>
      {loading && <p>Loading...</p>}
      {!loading && (
        <PieChart data={data}>
          {/* Your chart rendering */}
        </PieChart>
      )}
    </div>
  );
}

// EXAMPLE 4: Swap form
export function SwapForm() {
  const { isConnected, walletAddress } = useStore();
  const [fromToken, setFromToken] = useState('DAI');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSwap = async () => {
    if (!isConnected || !amount) return;

    setLoading(true);
    try {
      const tokenConfig = {
        DAI: { address: DAI_ADDRESS, decimals: 18 },
        USDC: { address: USDC_ADDRESS, decimals: 6 }
      }[fromToken];

      const amountIn = parseUnits(amount, tokenConfig.decimals);

      // Approve
      await approve(tokenConfig.address, '0x3F947239...', amount, tokenConfig.decimals);

      // Swap
      const path = [tokenConfig.address, USDC_ADDRESS];
      await swapExactTokens(amountIn, path, walletAddress, 1);

      alert('Swap successful!');
    } catch (error) {
      alert('Swap failed: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        placeholder="Amount"
      />
      <button onClick={handleSwap} disabled={loading}>
        {loading ? 'Swapping...' : 'Swap'}
      </button>
    </div>
  );
}

// ============================================================================
// COMMON PATTERNS
// ============================================================================

/**
 * Pattern 1: Auto-refresh data with cleanup
 */
useEffect(() => {
  const fetch = async () => {
    // Your fetch logic
  };

  fetch(); // Initial load
  const interval = setInterval(fetch, 30000); // Every 30s
  return () => clearInterval(interval); // Cleanup on unmount
}, [dependencies]);

/**
 * Pattern 2: Error handling with fallback
 */
try {
  const data = await someAsyncFunction();
  setData(data);
} catch (error) {
  console.error('Error:', error.message);
  setData([]); // Fallback value
}

/**
 * Pattern 3: Loading state
 */
setLoading(true);
try {
  // ... async operation ...
} catch (error) {
  // ... handle error ...
} finally {
  setLoading(false); // ALWAYS clear loading
}

/**
 * Pattern 4: Conditional rendering based on wallet
 */
if (!isConnected) {
  return <p>Connect wallet to view data</p>;
}
// Render data here

// ============================================================================
// ENVIRONMENT SETUP
// ============================================================================

/**
 * .env file (in frontend/ directory)
 */
// VITE_TOKEN_ADDRESS=0xDD13E55209Fd76AfE204dBda4007C227904f0a81

/**
 * config.js imports
 */
// import { TOKEN_ADDRESS, DAI_ADDRESS, USDC_ADDRESS, ROUTER_ADDRESS, ... } from '../config.js';

// ============================================================================
// API REFERENCE
// ============================================================================

/**
 * getTotalSupply(tokenAddress: string): Promise<bigint>
 * Returns total supply in raw units (not formatted)
 * Usage: const supply = await getTotalSupply(TOKEN_ADDRESS);
 */

/**
 * getBalance(tokenAddress: string, address: string): Promise<string>
 * Returns user balance
 */

/**
 * getTokenInfo(tokenAddress: string): Promise<{name, symbol, decimals}>
 * Returns token metadata
 */

/**
 * getHoldersDistribution(tokenAddress: string, top?: number): Promise<Array>
 * Returns array of top holders with percentages
 * Perfect for pie chart!
 */

/**
 * getTokenPrice(tokenAddress: string, stableAddress?: string, decimals?: number): Promise<number>
 * Returns price of token in stable token (default DAI)
 * Usage: const price = await getTokenPrice(TOKEN, DAI, 18);
 * Returns: 0.0523 for example
 */

/**
 * getPairLiquidity(tokenA: string, tokenB: string): Promise<{pairAddress, token0, token1, reserve0, reserve1}>
 * Returns pair data from Uniswap factory
 */

/**
 * swapExactTokens(amountIn: bigint, path: string[], recipient: string, slippagePercent?: number): Promise<receipt>
 * Executes swap via router (requires prior approval!)
 */

/**
 * approve(tokenAddress: string, spender: string, amount: string, decimals: number): Promise<receipt>
 * Approves spender to use tokens
 * Usage: await approve(DAI, ROUTER, '100', 18);
 */

/**
 * estimateGasFee(): Promise<string>
 * Returns estimated gas fee in ETH
 */

// ============================================================================
// DEPLOYMENT CHECKLIST
// ============================================================================

/**
 * Before deploying:
 * 
 * ✅ Set VITE_TOKEN_ADDRESS in .env (your deployed token)
 * ✅ Run: npm run build (check for errors)
 * ✅ All pages load without console errors
 * ✅ Wallet connects to Sepolia
 * ✅ Data loads on dashboard
 * ✅ Charts render (holders distribution)
 * ✅ Liquidity page shows pair data
 * ✅ Swap form works end-to-end
 * ✅ Error handling shows user-friendly messages
 * ✅ Dark mode works
 * ✅ Mobile responsive (test on phone)
 * 
 * Deploy to:
 * - Vercel: vercel (configure env vars)
 * - Netlify: netlify deploy --prod --dir dist
 * - Manual: Upload dist/ folder to web server
 */

// ============================================================================
// SUPPORT
// ============================================================================

/**
 * Troubleshooting:
 * 
 * Q: Price shows 0
 * A: Ensure DAI/USDC pair exists with liquidity on Sepolia
 * 
 * Q: Holders shows empty
 * A: Token must have some transfer history. Make transfers first.
 * 
 * Q: Liquidity shows null
 * A: No pair created yet. Add liquidity via Uniswap interface first.
 * 
 * Q: Swap fails with "allowance" error
 * A: Approve step not working. Try increasing gas limit.
 * 
 * Q: Data doesn't refresh
 * A: Check browser console for errors. Ensure wallet is connected.
 * 
 * For more help, see: SEPOLIA_INTEGRATION_GUIDE.md
 */
