# 🚀 GET STARTED IN 5 MINUTES

Everything you need to run your dashboard right now.

---

## Step 1: Setup (1 minute)

```bash
cd frontend

# Ensure .env has your token address
cat .env
# Should show: VITE_TOKEN_ADDRESS=0xDD13E552...
# If not, edit it:
# echo "VITE_TOKEN_ADDRESS=0xYOUR_TOKEN_ADDRESS" > .env
```

---

## Step 2: Install Dependencies (2 minutes)

```bash
npm install
```

---

## Step 3: Start Development Server (30 seconds)

```bash
npm run dev
```

**Output**: You'll see:
```
  VITE v5.4.21  ready in 123 ms

  ➜  Local:   http://localhost:5173/
  ➜  press h + enter to show help
```

---

## Step 4: Open in Browser

Click the link or open: **http://localhost:5173**

---

## Step 5: Connect Wallet (30 seconds)

1. Click **"Connect Wallet"** button (top right)
2. **MetaMask** pops up → Click **"Connect"**
3. MetaMask auto-switches to **Sepolia**
4. Dashboard loads with **live data**

✅ **Done!** Your dashboard is running.

---

## 🎯 What You See

### Home Page
- **Total Supply** - Live from contract
- **Total Holders** - From transfer events
- **Token Price** - From router
- **Market Cap** - Calculated
- **Gas Fee** - Live estimate
- **Charts** - Live holder distribution

### Liquidity Page
- **Token Reserve** - From pair
- **ETH Reserve** - From pair
- **TVL** - Calculated
- **LP Tokens** - Calculated

### Swap Page
- **Select tokens** - DAI, USDC, or TOKEN
- **See price** - Live estimation
- **Adjust slippage** - Safety setting
- **Execute swap** - Approve + trade

---

## 📋 All Available Commands

```bash
# Development
npm run dev              # Start dev server (auto-reload)

# Production
npm run build           # Build for production
npm run preview         # Preview production build locally

# Check
npm run lint            # Lint check (if configured)
```

---

## 🔧 Troubleshooting

### Problem: "Port 5173 already in use"
```bash
# Use different port
npm run dev -- --port 3000
```

### Problem: "Cannot find module errors"
```bash
# Clear and reinstall
rm -rf node_modules package-lock.json
npm install
npm run dev
```

### Problem: "MetaMask not detected"
- Install MetaMask browser extension
- Refresh the page

### Problem: "Wrong network"
- MetaMask should auto-switch to Sepolia
- If not, manually add Sepolia network:
  - Chain ID: 11155111
  - RPC: https://rpc.sepolia.org

---

## 📊 Dashboard Features

### ✅ Automatically Working
- Live token supply display
- Live price feed
- Holder distribution chart
- Liquidity pool data
- Gas fee estimates
- Owner badge (if you're owner)
- Dark mode
- Mobile responsive

### ✅ Ready to Use
- Token swap
- Mint/Burn (if owner)
- Pause/Unpause (if owner)

### ✅ Auto-Updates Every 30 Seconds
- Supply data
- Price data
- Holder distribution
- Liquidity data

---

## 🎯 Test the Features

### 1. View Data (Should see immediately)
- All stat cards populate
- Charts render
- Liquidity shows reserves

### 2. Try Swap
- Go to "Swap" tab
- Select tokens
- See live price quote
- Click "Swap" to execute

### 3. Check Owner Features
- Go to "Owner Panel" (if you're owner)
- See mint/burn options
- See pause option

---

## 💡 Useful URLs

```
Local dev:     http://localhost:5173
Sepolia RPC:   https://rpc.sepolia.org
Sepolia Block: https://sepolia.etherscan.io
Token Faucet:  https://sepoliafaucet.com
```

---

## 📱 Test on Mobile

While dev server is running:
1. Find your computer's IP: `ipconfig getifaddr en0` (Mac) or `ipconfig` (Windows)
2. On mobile: `http://YOUR_IP:5173`
3. Dashboard is mobile-responsive

---

## 🔐 Security Notes

✅ Wallet connected locally (MetaMask handles signing)  
✅ No private keys stored in app  
✅ All transactions go through MetaMask  
✅ Contract interactions validated before sending  

---

## 📖 Want to Learn More?

```
Quick overview:          INTEGRATION_COMPLETE.md
Complete guide:          SEPOLIA_INTEGRATION_GUIDE.md
Code examples:           LIVE_DATA_CODE_SNIPPETS.md
All docs:                MASTER_DOCUMENTATION.md
```

---

## 🚀 Production Deployment

When ready to go live:

```bash
# Build for production
npm run build

# Deploy to Vercel (easiest)
npm i -g vercel
vercel --prod
# Set VITE_TOKEN_ADDRESS env var in Vercel dashboard

# OR Deploy to Netlify
npm i -g netlify-cli
netlify deploy --prod --dir dist
# Set VITE_TOKEN_ADDRESS in Netlify dashboard

# OR Deploy to your own server
# Upload dist/ folder to your server
# Configure server to serve index.html for all routes
```

---

## ✅ Verification Checklist

After starting with `npm run dev`:

- [ ] Browser opens http://localhost:5173
- [ ] Page loads without errors
- [ ] "Connect Wallet" button visible
- [ ] Click connect → MetaMask appears
- [ ] Accept connection
- [ ] MetaMask switches to Sepolia (or prompts to add)
- [ ] Dashboard loads with data
- [ ] All stat cards show numbers
- [ ] Charts render
- [ ] You see "OWNER" badge if you're owner
- [ ] Swap page loads

**All checked? You're ready to go!** ✅

---

## 🎉 You're All Set!

Your React frontend is running and connected to Sepolia testnet.

**Next:**
1. Share dashboard URL with team
2. Test swap functionality
3. Monitor live data updates
4. Deploy to production when ready

---

**Happy trading!** 🚀

For issues, see SEPOLIA_INTEGRATION_GUIDE.md troubleshooting section.
