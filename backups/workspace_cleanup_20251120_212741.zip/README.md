# KhanX DEX - Uniswap V2 Clone on Sepolia

A production-ready Uniswap-style decentralized exchange built with Solidity, Hardhat, and React.

## Quick Start

### 1. Local Deployment (for testing)

```bash
# Terminal 1: Start Hardhat node
npx hardhat node --port 8666

# Terminal 2: Deploy to local network
npx hardhat run scripts/deploy-swap.js --network localhost

# Terminal 3: Start frontend
cd frontend
npm install
npm run dev
```

Open http://localhost:5174 in your browser.

### 2. Sepolia Testnet Deployment

```bash
# Setup environment
cp .env.example .env
# Edit .env with your Alchemy RPC URL and private key

# Deploy
npx hardhat run scripts/deploy-sepolia.js --network sepolia

# Frontend automatically updates with new addresses
cd frontend
npm run dev
```

See [SEPOLIA_DEPLOYMENT.md](./SEPOLIA_DEPLOYMENT.md) for detailed instructions.

## Project Structure

```
├── contracts/              # Solidity smart contracts
│   ├── UniswapV2Factory.sol    # DEX factory & pair
│   ├── UniswapV2Router02.sol   # Swap router
│   ├── MockERC20.sol           # Test tokens
│   └── MyToken.sol             # KhanX token
│
├── scripts/
│   ├── deploy.js           # Deploy to localhost
│   └── deploy-sepolia.js   # Deploy to Sepolia
│
├── frontend/               # React + Vite frontend
│   ├── src/
│   │   ├── components/     # React components
│   │   │   ├── SwapBox.jsx
│   │   │   ├── ConnectWallet.jsx
│   │   │   ├── TokenModal.jsx
│   │   │   └── ErrorBoundary.jsx
│   │   ├── utils/          # Web3 utilities
│   │   │   ├── wallet.js
│   │   │   ├── swap.js
│   │   │   └── getProvider.js
│   │   └── config.js       # Contract addresses
│   └── package.json
│
├── hardhat.config.cjs      # Hardhat configuration
├── .env.example            # Environment template
└── SEPOLIA_DEPLOYMENT.md   # Detailed deployment guide
```

## Features

✅ **ERC20 Tokens**: Deploy custom tokens  
✅ **Constant-Product AMM**: Uniswap V2-style swap mechanics  
✅ **Liquidity Pools**: Add/remove liquidity  
✅ **Token Swaps**: Exact input/output swaps with slippage protection  
✅ **MetaMask Integration**: Connect and switch networks  
✅ **Sepolia Support**: Full testnet integration  
✅ **Clean UI**: Professional Tailwind CSS design  
✅ **Error Handling**: React error boundaries  

## Contracts

| Contract | Purpose | Details |
|----------|---------|---------|
| `UniswapV2Factory` | Pair creation | Creates and tracks pairs |
| `UniswapV2Pair` | Liquidity pool | Handles swaps and reserves |
| `UniswapV2Router02` | Routing | Executes swaps and liquidity ops |
| `MockERC20` | Test tokens | Simple ERC20 implementation |

## Key Functions

### Swap Tokens
```javascript
import { swapTokens } from './utils/swap.js';
await swapTokens(tokenIn, tokenOut, amount, userAddress);
```

### Add Liquidity
```javascript
import { addLiquidity } from './utils/swap.js';
await addLiquidity(amountA, amountB, userAddress);
```

### Connect Wallet
```javascript
import { connectWallet, switchToSepolia } from './utils/wallet.js';
const address = await connectWallet();
await switchToSepolia();
```

## Environment Variables

```env
ALCHEMY_SEPOLIA_URL=https://eth-sepolia.g.alchemy.com/v2/YOUR_KEY
PRIVATE_KEY=your_wallet_private_key
```

## Technologies

- **Contracts**: Solidity 0.8.19/0.8.20
- **Development**: Hardhat, ethers.js v6
- **Frontend**: React 18, Vite, Tailwind CSS
- **Network**: Sepolia testnet (chainId: 11155111)

## Sepolia WETH Address

```
0xDD13E55209Fd76AfE204dBda4007C227904f0a81
```

## Frontend

- **URL**: http://localhost:5174 (dev) or your deployment URL
- **Wallet**: MetaMask (or any EIP-1193 provider)
- **Network**: Sepolia testnet
- **Features**: Swap UI, token selector, balance display, gas estimates

## Getting Help

1. Check [SEPOLIA_DEPLOYMENT.md](./SEPOLIA_DEPLOYMENT.md) for deployment issues
2. Review contract ABIs in `frontend/src/abi/`
3. Check console logs in browser DevTools
4. Verify contract addresses in `frontend/config.js`

## Security Notes

⚠️ **Important**:
- Never commit `.env` to version control
- Keep private keys confidential
- Test thoroughly on Sepolia before mainnet
- Consider audits for production deployment

## License

MIT

---

**Built with ❤️ for DeFi developers**
